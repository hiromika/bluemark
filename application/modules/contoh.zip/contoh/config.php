<?php
$config = array(
    "name" => 'Contoh Module',
    "slug" => 'contoh',
    "description" => "Contoh membuat module menggunakan framework Bama"
);
?>