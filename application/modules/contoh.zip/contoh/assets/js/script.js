/* Grid column formatter for graph */
function graphFormat(val, row) {
    return '<span style="color:red;"><a href="javascript:void(0)">GRAFIK</a></span>';
}